% ��Ė@

% �����Ɍ�␶���C���f�b�N�X�A�c����MET�����A�J��Ԃ����Ƃ�MET�̕ϑJ���m�F
% �����Ɍ�␶���C���f�b�N�X�A�c���ɁbPS_out-�^�̑��M�M���x�N�g���b�����A�m�F����

% Best PS Selection
clear;
Trial = 10000;
M = 4;
k = log2(M);
NT = 4;
NR = 4;
Alpha = 1.5;
Alpha_Uni = 1.5;
Temp = 3.0; % (NT-4)/2
Np=1;
Ns=1;

EBMAX = 30;
EBSTEP = 2;
BERpropMHGD = zeros(1,EBMAX/EBSTEP+1);
BERMHGD = zeros(1,EBMAX/EBSTEP+1);
% MET_MHGD = zeros(Trial,Ns,EBMAX/EBSTEP+1);
% signal = zeros(Trial,Ns,EBMAX/EBSTEP+1);
propM = zeros(Trial,Ns);
convM = zeros(Trial,Ns);
% propEuclid = zeros(Trial,Ns);
% convEuclid = zeros(Trial,Ns);
countISP_prop = zeros(Trial,1);
ISP_return_prop = zeros(Trial,1);
P_ISP_prop = zeros(Trial,1);
countISP_conv = zeros(Trial,1);
ISP_return_conv = zeros(Trial,1);
P_ISP_conv = zeros(Trial,1);

for EbNo=0:EBSTEP:EBMAX
    var = 10^(-EbNo/10)*NR*2/2;
    numErrs_prop = 0;
    numErrs_conv = 0;

    for index=1:Trial
%         EbNo
%         index
        if mod(index,1000)==0
          index
        end
        %%%%% TX Data %%%%%             
        dataIn = randi([0 1],NT,k);              % Generate binary data
        dataSym = bi2de(dataIn);                    % Convert to symbols
        S = qammod(dataSym,M);                      % QAM modulate using 'Gray' symbol mapping

        %%%%% RX Signal %%%%%
        CH = sqrt(1/2).*(randn(NR,NT) + j*randn(NR,NT));           % NR�sNT��̐��K�����ꂽ�`���l���s��𐶐�
        Z = CH*S + sqrt(var/2).*(randn(NR,1) + j*randn(NR,1));      % �`���l���s��Ƒ��M�M������Z���A�G���i����0,���Uvar�j�������Ă���@

        %%%%% Detection %%%%%
        [MHGDprop,MHGDmet,signal_out,moveprop,keepprop,Eprop,uISP_prop,ISPr_prop] = propMHGD_QPSK( S, Z, CH, NT, NR, Alpha_Uni, var, Np, Ns);
        [MHGD,met,sig,move,keep,Econv,uISP_conv,ISPr_conv] = MHGD_QPSK( S, Z, CH, NT, NR, Alpha_Uni, var, Np, Ns);

        %%%%% TX Data %%%%%

        rxSym_prop = qamdemod(MHGDprop,M);
        rxSym_conv = qamdemod(MHGD,M);
        dataOut_prop = de2bi(rxSym_prop,k);
        dataOut_conv = de2bi(rxSym_conv,k);
        
        nErrors_prop = biterr(dataIn,dataOut_prop);
        nErrors_conv = biterr(dataIn,dataOut_conv);
        
        numErrs_prop = numErrs_prop + nErrors_prop;
        numErrs_conv = numErrs_conv + nErrors_conv;

        
        countISP_prop(index) = uISP_prop;
        ISP_return_prop(index) = ISPr_prop;
        P_ISP_prop(index) = ISPr_prop/uISP_prop;
        countISP_conv(index) = uISP_conv;
        ISP_return_conv(index) = ISPr_conv;
        P_ISP_conv(index) = ISPr_conv/uISP_conv;
        
%         MET_MHGDprop(index,:,EbNo/EBSTEP+1) = MHGDmet;
        propM(index,:) = moveprop;
        convM(index,:) = move;
%         propEuclid(index,:) = Eprop;
%         convEuclid(index,:) = Econv; 
%         propK(index,:) = keepprop;
%         K(index,:) = keep;
        
%         for i=1:Ns
%             signal(index,i,EbNo/EBSTEP+1) = sqrt(sum(abs(signal_out(:,i) - S).^2));
%         end
        
    end
    
    BERpropMHGD(EbNo/EBSTEP+1) = numErrs_prop/(2*NT*Trial);
    BERMHGD(EbNo/EBSTEP+1) = numErrs_conv/(2*NT*Trial);
    
%     count_MHGD(EbNo/EBSTEP+1) = MHGDnumber;
    
end



% c = reshape(propG,1,[]);
% d = reshape(G,1,[]);

% hold on
% EB = 0:EBSTEP:EBMAX;
% semilogy(EB,BERpropMHGD,'b')
% % semilogy(EB,BERMHGD, 'r')
% xlabel('Eb/N0','FontSize',14)
% ylabel('BER','FontSize',14)
% hold off

strTrl = num2str(Trial);
strNs = num2str(Ns);
strNT = num2str(NT);
filename = ['QPSK_',datestr(now,'yymmdd_HHMM'),'_trial',strTrl,'_N',strNT,'_Ns',strNs,'_20dB'];
save(filename);