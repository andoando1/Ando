function [PS,MET_out,signal_original,Move, PSkeep,Euclid,useISP,ISP_return] = MHGD_64QAM(S, Z, CH, NT, NR, Alpha, var, Np, Ns) %%%% MH Algorithm

        %%%% Z : NR�s�P��̎�M�M���@�@CH : NR�sNT��̃`���l���s��@�@
        
        MET = inf;
        MET_out = zeros([1 Ns]);        % �����Ɍ�␶���C���f�b�N�X�A�c����MET�����A�J��Ԃ����Ƃ�MET�̕ϑJ���m�F
        signal_original = zeros([NT Ns]);   % �����Ɍ�␶���C���f�b�N�X�A�c���ɁbPS_out-�^�̑��M�M���x�N�g���b�����A�m�F����
        CHZ = CH'*Z;
        CHCH = CH'*CH;
        distance = zeros([1 Ns+1]);
        Move = zeros([1 Ns]);
        PSkeep = zeros([NT Ns]);
        Euclid = zeros([1 Ns]);
        prevISP = zeros([1 Ns]);    % i-1��ڂ̒T���ɂ����Ă�ISP���g�����ꍇ��1,�g��Ȃ������ꍇ��0��ۑ�(ISP : Intermediate Search Point)
        useISP = 0;                 % ���ԒT���_���g�p�����񐔁i���M�V���{�����~�A���e�i���̂�������g�������j
        ISP_return = 0;             % ���ԒT���_�𗘗p���Č��𐶐������ۂɁC���̐M���_�ɖ߂��
        
for sampler=1:Np        % ����T���v���[
    sampler;
       
    PS = pinv(CH)*Z;        % �����l
%     PS = zeros([NT 1]);
    T = zeros(NT);
    CH_t=inv(CH);
        
        for i=1:NT
            T(i,i) = 1/norm(CH_t(:,i)); 
        end
    
    I=eye(NT);                        % NT�~NT�̒P�ʍs��
    dqam=1;                           % (QAM�i�q�Ԃ̍ŒZ����)�^2
    Mp=inv(CHCH+(var/dqam^2)*I);    % (H'H+rI)^-1
    Mc = CH_t*T;                      % H^-1*T
        
    for Counter=1:Ns
        
        if Counter == 1
            for i=1:NT          % �����̗ʎq��
                if real(PS(i)) >= 6
                        PS(i) = 7 + imag(PS(i))*sqrt(-1);
                elseif real(PS(i)) >= 4 && real(PS(i)) < 6
                        PS(i) = 5 + imag(PS(i))*sqrt(-1);
                elseif real(PS(i)) >= 2 && real(PS(i)) < 4
                        PS(i) = 3 + imag(PS(i))*sqrt(-1);
                elseif real(PS(i)) >= 0 && real(PS(i)) < 2
                        PS(i) = 1 + imag(PS(i))*sqrt(-1);
                elseif real(PS(i)) >= -2 && real(PS(i)) < 0
                        PS(i) = -1 + imag(PS(i))*sqrt(-1);
                elseif real(PS(i)) >= -4 && real(PS(i)) < -2
                        PS(i) = -3 + imag(PS(i))*sqrt(-1);
                elseif real(PS(i)) >= -6 && real(PS(i)) < -4
                        PS(i) = -5 + imag(PS(i))*sqrt(-1);
                else
                        PS(i) = -7 + imag(PS(i))*sqrt(-1);
                end
            
                if imag(PS(i)) >= 6     % �����̗ʎq��
                        PS(i) = real(PS(i)) + 7*sqrt(-1);
                elseif imag(PS(i)) >= 4 && imag(PS(i)) < 6
                        PS(i) = real(PS(i)) + 5*sqrt(-1);
                elseif imag(PS(i)) >= 2 && imag(PS(i)) < 4
                        PS(i) = real(PS(i)) + 3*sqrt(-1);
                elseif imag(PS(i)) >= 0 && imag(PS(i)) < 2
                        PS(i) = real(PS(i)) + 1*sqrt(-1);
                elseif imag(PS(i)) >= -2 && imag(PS(i)) < 0
                        PS(i) = real(PS(i)) - 1*sqrt(-1);
                elseif imag(PS(i)) >= -4 && imag(PS(i)) < -2
                        PS(i) = real(PS(i)) - 3*sqrt(-1);
                elseif imag(PS(i)) >= -6 && imag(PS(i)) < -4
                        PS(i) = real(PS(i)) - 5*sqrt(-1);
                else
                        PS(i) = real(PS(i)) - 7*sqrt(-1);
                end
            end
            distance(Counter) = sqrt(sum(abs(S-PS).^2)/NT);
        end
        
        %% ���̌��̐���
%         Gradient(Counter) = sqrt(sum(abs(CH'*(Z-CH*PS)).^2));
        PSgrad = PS + Mp*CH'*(Z-CH*PS);
            s = max(dqam, abs(Z-CH*PS)/sqrt(NT));
            v = sqrt(1/2).*(randn(NT,1) + sqrt(-1)*randn(NT,1));
        PSprop = PSgrad+s.*Mc*v;
        
        %% PSprop�̗ʎq��  xprop = Q(zprop)

            for i=1:NT          % �����̗ʎq��
                if real(PSprop(i)) >= 6
                        PSprop(i) = 7 + imag(PSprop(i))*sqrt(-1);
                elseif real(PSprop(i)) >= 4 && real(PSprop(i)) < 6
                        PSprop(i) = 5 + imag(PSprop(i))*sqrt(-1);
                elseif real(PSprop(i)) >= 2 && real(PSprop(i)) < 4
                        PSprop(i) = 3 + imag(PSprop(i))*sqrt(-1);
                elseif real(PSprop(i)) >= 0 && real(PSprop(i)) < 2
                        PSprop(i) = 1 + imag(PSprop(i))*sqrt(-1);
                elseif real(PSprop(i)) >= -2 && real(PSprop(i)) < 0
                        PSprop(i) = -1 + imag(PSprop(i))*sqrt(-1);
                elseif real(PSprop(i)) >= -4 && real(PSprop(i)) < -2
                        PSprop(i) = -3 + imag(PSprop(i))*sqrt(-1);
                elseif real(PSprop(i)) >= -6 && real(PSprop(i)) < -4
                        PSprop(i) = -5 + imag(PSprop(i))*sqrt(-1);
                else
                        PSprop(i) = -7 + imag(PSprop(i))*sqrt(-1);
                end

                if imag(PSprop(i)) >= 6
                        PSprop(i) = real(PSprop(i)) + 7*sqrt(-1);
                elseif imag(PSprop(i)) >= 4 && imag(PSprop(i)) < 6
                        PSprop(i) = real(PSprop(i)) + 5*sqrt(-1);
                elseif imag(PSprop(i)) >= 2 && imag(PSprop(i)) < 4
                        PSprop(i) = real(PSprop(i)) + 3*sqrt(-1);
                elseif imag(PSprop(i)) >= 0 && imag(PSprop(i)) < 2
                        PSprop(i) = real(PSprop(i)) + 1*sqrt(-1);
                elseif imag(PSprop(i)) >= -2 && imag(PSprop(i)) < 0
                        PSprop(i) = real(PSprop(i)) - 1*sqrt(-1);
                elseif imag(PSprop(i)) >= -4 && imag(PSprop(i)) < -2
                        PSprop(i) = real(PSprop(i)) - 3*sqrt(-1);
                elseif imag(PSprop(i)) >= -6 && imag(PSprop(i)) < -4
                        PSprop(i) = real(PSprop(i)) - 5*sqrt(-1);
                else
                        PSprop(i) = real(PSprop(i)) - 7*sqrt(-1);
                end
            end
            
            %% ���ԒT���_��p���Ď��̌��𐶐������ꍇ�Ɍ��̐M���_�ɖ߂�񐔂��J�E���g
%         for i = 1:NT
%             if PSprop(i) == PS(i)
%                 if prevISP(i) == 1
%                     ISP_return = ISP_return + 1;
%                 end
%             end
%         end
        
        %% MHGD�A���S���Y���ɂ�锻��
        METp = exp(sum(abs(Z - CH*PS).^2/(-1*var*Alpha^2)));
        METn = exp(sum(abs(Z - CH*PSprop).^2/(-1*var*Alpha^2)));
        
        if rand < min(1, METn/METp)
            if PS(i) == PSprop(i)
                useISP = useISP + 1;        % ���ԒT���_���g�p������
                prevISP(i) = 1;
            else
                prevISP(i) =0;
            end
            PS=PSprop;
        else
            prevISP(1,:) = 0;
        end
        
        %% �^�̑��M�M���ɑ΂���ړ��� %%
            distance(Counter + 1) = sqrt(sum(abs(S-PS).^2)/NT);
            Move(Counter) = distance(Counter) - distance(Counter + 1);
            
        %% �œK���Ƃ̃��[�N���b�h����
%         if Counter == 1
%             Euclid(Counter) = sqrt(sum(abs(S-PS).^2)/NT);
%         elseif Counter == 10
%             Euclid(Counter) = sqrt(sum(abs(S-PS).^2)/NT);
%         elseif Counter == 100
%             Euclid(Counter) = sqrt(sum(abs(S-PS).^2)/NT);
%         elseif Counter == 1000
%             Euclid(Counter) = sqrt(sum(abs(S-PS).^2)/NT);
%         elseif Counter == 10000
%             Euclid(Counter) = sqrt(sum(abs(S-PS).^2)/NT);
%         end

        %% ��������ԋ߂����̂̕ۑ� %%
        if MET > sum(abs(Z - CH*PS).^2)
            MET = sum(abs(Z - CH*PS).^2);
            PS_out = PS;
        end
       
%         PSkeep(:,Counter) = PSprop;
        if Counter == 10000
            PSkeep = PS;
        end

    end
end
    
    PS = PS_out;
    
end