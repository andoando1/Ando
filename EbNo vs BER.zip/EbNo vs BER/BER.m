hold on
EB = 0:EBSTEP:EBMAX;
semilogy(EB,BERpropMHGD,'r')
semilogy(EB,BERMHGD, 'r')
legend('Propoesd MHGD (Ns=1000)','Conventional MHGD (Ns=1000)')
xlabel('E_b/N_0','FontSize',14)
ylabel('BER','FontSize',14)
hold off